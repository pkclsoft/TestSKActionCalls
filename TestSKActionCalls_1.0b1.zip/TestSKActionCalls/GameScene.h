#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene

#pragma mark - Construction

+ (GameScene*) gameSceneWithSize:(CGSize)size;

@end
