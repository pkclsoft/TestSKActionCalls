//
//  SKContainerNode.h
//  TestTextureUpdates
//
//  Created by Peter Easdown on 23/1/17.
//  Copyright © 2017 PKCLsoft. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKContainerNode : SKNode

@end
