//
//  AppDelegate.h
//  TestTextureUpdates
//
//  Created by Peter Easdown on 11/1/17.
//  Copyright © 2017 PKCLsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

